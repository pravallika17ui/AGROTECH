import React from 'react';
import { SensorReading } from '../../types';

interface SensorChartProps {
  data: SensorReading[];
  title: string;
  color: string;
}

const SensorChart: React.FC<SensorChartProps> = ({ data, title, color }) => {
  // Find min/max values for scaling
  const values = data.map(reading => reading.value);
  const maxValue = Math.max(...values);
  const minValue = Math.min(...values);
  const range = maxValue - minValue;
  
  const normalizeValue = (value: number) => {
    return ((value - minValue) / (range || 1)) * 100;
  };
  
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getLatestReading = () => {
    if (data.length === 0) return null;
    return data[data.length - 1];
  };
  
  const latestReading = getLatestReading();
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className={`p-4 ${color} text-white`}>
        <h3 className="font-semibold">{title}</h3>
      </div>
      
      <div className="p-4">
        {latestReading && (
          <div className="flex justify-between items-center mb-4">
            <span className="text-gray-500 text-sm">Current:</span>
            <span className="text-2xl font-bold">{latestReading.value} {latestReading.unit}</span>
          </div>
        )}
        
        <div className="h-40 relative">
          <div className="absolute inset-0 flex items-end">
            {data.map((reading, index) => {
              const height = normalizeValue(reading.value);
              return (
                <div 
                  key={index} 
                  className="flex-1 flex flex-col items-center justify-end group"
                >
                  <div className="relative">
                    <div 
                      className={`${color} opacity-80 w-4 rounded-t-sm mx-auto transition-all duration-300 hover:opacity-100 group-hover:w-6`}
                      style={{ height: `${height}%` }}
                    ></div>
                    
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
                      {reading.value} {reading.unit}
                    </div>
                  </div>
                  
                  {index % 3 === 0 && (
                    <span className="text-xs text-gray-500 mt-1">{formatTime(reading.timestamp)}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SensorChart;