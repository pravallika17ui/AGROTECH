import React, { useState } from 'react';
import { 
  Bell, 
  User, 
  Shield, 
  Smartphone, 
  Globe, 
  Database, 
  Sliders,
  Mail,
  Phone
} from 'lucide-react';

const SettingsDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('profile');
  
  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-green-600 text-white">
                <h3 className="font-semibold">Personal Information</h3>
              </div>
              
              <div className="p-4">
                <div className="flex items-center mb-6">
                  <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mr-4">
                    <User size={32} className="text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-800">John Farmer</h4>
                    <p className="text-gray-600">Farm Owner</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <div className="flex items-center">
                      <Mail size={16} className="text-gray-400 mr-2" />
                      <input
                        type="email"
                        value="john@example.com"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <div className="flex items-center">
                      <Phone size={16} className="text-gray-400 mr-2" />
                      <input
                        type="tel"
                        value="+1 (555) 123-4567"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-blue-600 text-white">
                <h3 className="font-semibold">Farm Information</h3>
              </div>
              
              <div className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Farm Name
                    </label>
                    <input
                      type="text"
                      value="Green Valley Farm"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Total Area
                    </label>
                    <input
                      type="text"
                      value="150 hectares"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <textarea
                      rows={3}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      defaultValue="123 Farm Road, Agricultural District, Country"
                    ></textarea>
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Update Farm Details
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'notifications':
        return (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-amber-600 text-white">
              <h3 className="font-semibold">Notification Preferences</h3>
            </div>
            
            <div className="p-4">
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">Alert Settings</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Bell size={20} className="text-amber-500 mr-3" />
                        <div>
                          <p className="font-medium">Critical Alerts</p>
                          <p className="text-sm text-gray-500">
                            Immediate notifications for urgent issues
                          </p>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                      </label>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Smartphone size={20} className="text-amber-500 mr-3" />
                        <div>
                          <p className="font-medium">Mobile Notifications</p>
                          <p className="text-sm text-gray-500">
                            Push notifications to your mobile device
                          </p>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                      </label>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Mail size={20} className="text-amber-500 mr-3" />
                        <div>
                          <p className="font-medium">Email Notifications</p>
                          <p className="text-sm text-gray-500">
                            Daily summary and reports
                          </p>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">Notification Categories</h4>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-amber-600 focus:ring-amber-500"
                        defaultChecked
                      />
                      <span className="ml-2">Weather Alerts</span>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-amber-600 focus:ring-amber-500"
                        defaultChecked
                      />
                      <span className="ml-2">Crop Health Updates</span>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-amber-600 focus:ring-amber-500"
                        defaultChecked
                      />
                      <span className="ml-2">Irrigation System Alerts</span>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-amber-600 focus:ring-amber-500"
                        defaultChecked
                      />
                      <span className="ml-2">Pest Detection Alerts</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <button className="bg-amber-600 text-white px-4 py-2 rounded-md hover:bg-amber-700">
                  Save Preferences
                </button>
              </div>
            </div>
          </div>
        );
      
      case 'security':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-red-600 text-white">
                <h3 className="font-semibold">Security Settings</h3>
              </div>
              
              <div className="p-4">
                <div className="mb-6">
                  <h4 className="font-medium text-gray-800 mb-4">Change Password</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Current Password
                      </label>
                      <input
                        type="password"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        New Password
                      </label>
                      <input
                        type="password"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Confirm New Password
                      </label>
                      <input
                        type="password"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                      />
                    </div>
                  </div>
                  <div className="mt-4">
                    <button className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                      Update Password
                    </button>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">Two-Factor Authentication</h4>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <Shield size={20} className="text-red-500 mr-3" />
                      <div>
                        <p className="font-medium">2FA Status</p>
                        <p className="text-sm text-gray-500">
                          Add an extra layer of security to your account
                        </p>
                      </div>
                    </div>
                    <button className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                      Enable 2FA
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-gray-800 text-white">
                <h3 className="font-semibold">Login History</h3>
              </div>
              
              <div className="p-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Current Session</p>
                      <p className="text-sm text-gray-500">Chrome on Windows • IP: 192.168.1.1</p>
                    </div>
                    <span className="text-green-600 text-sm">Active Now</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Previous Login</p>
                      <p className="text-sm text-gray-500">Safari on iPhone • IP: 192.168.1.2</p>
                    </div>
                    <span className="text-gray-500 text-sm">Yesterday, 15:30</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'system':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-purple-600 text-white">
                <h3 className="font-semibold">System Settings</h3>
              </div>
              
              <div className="p-4">
                <div className="mb-6">
                  <h4 className="font-medium text-gray-800 mb-4">Data Management</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <Database size={20} className="text-purple-500 mr-3" />
                        <div>
                          <p className="font-medium">Data Storage</p>
                          <p className="text-sm text-gray-500">
                            Configure data retention policies
                          </p>
                        </div>
                      </div>
                      <button className="text-purple-600 hover:text-purple-800">
                        Configure
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <Globe size={20} className="text-purple-500 mr-3" />
                        <div>
                          <p className="font-medium">Language & Region</p>
                          <p className="text-sm text-gray-500">
                            Set your preferred language and timezone
                          </p>
                        </div>
                      </div>
                      <button className="text-purple-600 hover:text-purple-800">
                        Change
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <Sliders size={20} className="text-purple-500 mr-3" />
                        <div>
                          <p className="font-medium">System Preferences</p>
                          <p className="text-sm text-gray-500">
                            Customize system behavior and appearance
                          </p>
                        </div>
                      </div>
                      <button className="text-purple-600 hover:text-purple-800">
                        Customize
                      </button>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-800 mb-4">System Information</h4>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Version</p>
                        <p className="font-medium">2.1.0</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Last Update</p>
                        <p className="font-medium">March 15, 2024</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Database Size</p>
                        <p className="font-medium">1.2 GB</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Storage Used</p>
                        <p className="font-medium">45%</p>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <button className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700">
                        Check for Updates
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
        <p className="text-gray-600">Manage your account and system preferences.</p>
      </div>
      
      <div className="mb-6">
        <nav className="flex space-x-4">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'profile'
                ? 'bg-green-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Profile
          </button>
          <button
            onClick={() => setActiveTab('notifications')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'notifications'
                ? 'bg-amber-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Notifications
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'security'
                ? 'bg-red-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Security
          </button>
          <button
            onClick={() => setActiveTab('system')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'system'
                ? 'bg-purple-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            System
          </button>
        </nav>
      </div>
      
      {renderContent()}
    </div>
  );
};

export default SettingsDashboard;