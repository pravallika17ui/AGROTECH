import React, { useState } from 'react';
import { Menu, Bell, User, X } from 'lucide-react';
import { alerts } from '../../utils/mockData';
import { Alert } from '../../types';

interface NavbarProps {
  toggleSidebar: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  
  const unreadAlerts = alerts.filter(alert => !alert.read);
  
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getAlertColor = (type: Alert['type']) => {
    switch (type) {
      case 'critical':
        return 'bg-red-600';
      case 'warning':
        return 'bg-amber-500';
      case 'info':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <nav className="bg-white shadow-md px-4 py-3 flex justify-between items-center sticky top-0 z-10">
      <div className="flex items-center">
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-md text-gray-700 hover:bg-gray-100 focus:outline-none mr-4 lg:hidden"
        >
          <Menu size={24} />
        </button>
        <h1 className="text-xl md:text-2xl font-bold text-green-700">AgriSmart</h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="relative">
          <button
            className="p-2 rounded-full text-gray-700 hover:bg-gray-100 focus:outline-none relative"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <Bell size={20} />
            {unreadAlerts.length > 0 && (
              <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                {unreadAlerts.length}
              </span>
            )}
          </button>
          
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg overflow-hidden z-20">
              <div className="p-3 bg-green-50 border-b flex justify-between items-center">
                <h3 className="text-sm font-medium text-green-800">Notifications</h3>
                <button 
                  onClick={() => setShowNotifications(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={16} />
                </button>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {alerts.length === 0 ? (
                  <p className="text-center py-4 text-gray-500">No notifications</p>
                ) : (
                  <div>
                    {alerts.map(alert => (
                      <div key={alert.id} className={`p-3 border-b hover:bg-gray-50 ${!alert.read ? 'bg-blue-50' : ''}`}>
                        <div className="flex items-start">
                          <div className={`w-2 h-2 rounded-full mt-1.5 mr-2 ${getAlertColor(alert.type)}`}></div>
                          <div className="flex-1">
                            <p className="text-sm text-gray-800">{alert.message}</p>
                            <p className="text-xs text-gray-500 mt-1">{formatTime(alert.timestamp)}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="p-2 bg-gray-50 text-center">
                <button className="text-sm text-green-600 hover:text-green-800 font-medium">
                  View all notifications
                </button>
              </div>
            </div>
          )}
        </div>
        
        <div className="hidden md:flex items-center">
          <button className="flex items-center space-x-2 p-1 rounded-full hover:bg-gray-100">
            <div className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center">
              <User size={16} />
            </div>
            <span className="text-sm font-medium text-gray-700">John Farmer</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;