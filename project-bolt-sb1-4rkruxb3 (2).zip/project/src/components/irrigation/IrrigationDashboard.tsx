import React from 'react';
import { Play, Pause, Clock, AlertTriangle, Droplets } from 'lucide-react';
import { irrigationZones, sensorData } from '../../utils/mockData';

const IrrigationDashboard: React.FC = () => {
  const latestMoisture = sensorData.soilMoisture[sensorData.soilMoisture.length - 1]?.value || 0;
  
  const getMoistureStatus = (level: number) => {
    if (level >= 70) return { text: 'Optimal', color: 'text-green-600' };
    if (level >= 40) return { text: 'Adequate', color: 'text-blue-600' };
    return { text: 'Low', color: 'text-amber-600' };
  };
  
  const getZoneActionButton = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <button className="flex items-center px-3 py-1 rounded text-sm bg-red-100 text-red-700 hover:bg-red-200">
            <Pause size={14} className="mr-1" /> Stop
          </button>
        );
      case 'scheduled':
        return (
          <button className="flex items-center px-3 py-1 rounded text-sm bg-amber-100 text-amber-700 hover:bg-amber-200">
            <Clock size={14} className="mr-1" /> Reschedule
          </button>
        );
      case 'inactive':
        return (
          <button className="flex items-center px-3 py-1 rounded text-sm bg-green-100 text-green-700 hover:bg-green-200">
            <Play size={14} className="mr-1" /> Start
          </button>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Irrigation Management</h1>
        <p className="text-gray-600">Monitor and control your farm's irrigation system.</p>
      </div>
      
      {/* Summary statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow-md flex items-center">
          <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
            <Droplets size={24} className="text-blue-600" />
          </div>
          <div>
            <span className="text-sm text-gray-500">Average Soil Moisture</span>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-800">{latestMoisture}%</span>
              <span className={`ml-2 text-sm ${getMoistureStatus(latestMoisture).color}`}>
                {getMoistureStatus(latestMoisture).text}
              </span>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md flex items-center">
          <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
            <Play size={24} className="text-green-600" />
          </div>
          <div>
            <span className="text-sm text-gray-500">Active Zones</span>
            <div className="text-2xl font-bold text-gray-800">
              {irrigationZones.filter(z => z.status === 'active').length}
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md flex items-center">
          <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center mr-4">
            <AlertTriangle size={24} className="text-amber-600" />
          </div>
          <div>
            <span className="text-sm text-gray-500">Zones Needing Attention</span>
            <div className="text-2xl font-bold text-gray-800">
              {irrigationZones.filter(z => z.moistureLevel < 40).length}
            </div>
          </div>
        </div>
      </div>
      
      {/* Irrigation controls */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="p-4 bg-blue-600 text-white flex justify-between items-center">
          <h3 className="font-semibold">Irrigation Zones</h3>
          <div className="flex space-x-2">
            <button className="px-3 py-1 bg-white text-blue-600 rounded text-sm hover:bg-blue-50">
              Schedule All
            </button>
          </div>
        </div>
        
        <div className="divide-y">
          {irrigationZones.map(zone => {
            const moistureStatus = getMoistureStatus(zone.moistureLevel);
            return (
              <div key={zone.id} className="p-4 hover:bg-blue-50 transition-colors duration-200">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">{zone.name}</h4>
                  <div className="flex space-x-2">
                    <span className={`text-sm ${moistureStatus.color}`}>
                      {moistureStatus.text}
                    </span>
                    {getZoneActionButton(zone.status)}
                  </div>
                </div>
                
                <div className="mt-2">
                  <div className="flex items-center mb-1">
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${
                          zone.moistureLevel >= 70 ? 'bg-green-500' : 
                          zone.moistureLevel >= 40 ? 'bg-blue-500' : 
                          'bg-amber-500'
                        }`}
                        style={{ width: `${zone.moistureLevel}%` }}
                      ></div>
                    </div>
                    <span className="ml-3 text-sm">{zone.moistureLevel}% Moisture</span>
                  </div>
                  
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Last irrigated: {new Date(zone.lastIrrigated).toLocaleString()}</span>
                    {zone.status === 'scheduled' && zone.scheduledFor && (
                      <span>Next: {new Date(zone.scheduledFor).toLocaleString()}</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Smart recommendations */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-green-600 text-white">
          <h3 className="font-semibold">Smart Recommendations</h3>
        </div>
        
        <div className="p-4">
          <div className="mb-4 p-3 bg-blue-50 border-l-4 border-blue-500 rounded-sm">
            <h4 className="font-medium text-blue-700 mb-1">Optimize Irrigation Schedule</h4>
            <p className="text-sm text-gray-700">
              Based on weather forecast and soil moisture trends, consider rescheduling irrigation for the Corn Zone to tomorrow morning to avoid upcoming rainfall.
            </p>
            <div className="mt-2">
              <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                Apply Recommendation
              </button>
            </div>
          </div>
          
          <div className="mb-4 p-3 bg-yellow-50 border-l-4 border-yellow-500 rounded-sm">
            <h4 className="font-medium text-yellow-700 mb-1">Moisture Level Alert</h4>
            <p className="text-sm text-gray-700">
              Tomato Zone moisture levels have been below optimal for 48 hours. Consider increasing irrigation duration by 15 minutes.
            </p>
            <div className="mt-2">
              <button className="text-sm text-yellow-600 hover:text-yellow-800 font-medium">
                Apply Recommendation
              </button>
            </div>
          </div>
          
          <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded-sm">
            <h4 className="font-medium text-green-700 mb-1">Water Conservation Opportunity</h4>
            <p className="text-sm text-gray-700">
              Wheat Zone moisture levels are optimal. Consider reducing irrigation frequency to conserve water and reduce costs.
            </p>
            <div className="mt-2">
              <button className="text-sm text-green-600 hover:text-green-800 font-medium">
                Apply Recommendation
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IrrigationDashboard;