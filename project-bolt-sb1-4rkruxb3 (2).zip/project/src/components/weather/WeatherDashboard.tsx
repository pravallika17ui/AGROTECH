import React from 'react';
import { Cloud, CloudRain, Sun, Wind, Thermometer } from 'lucide-react';
import { weatherForecast, sensorData } from '../../utils/mockData';

const WeatherDashboard: React.FC = () => {
  const getWeatherIcon = (condition: string, size = 24) => {
    switch (condition) {
      case 'sunny':
        return <Sun size={size} className="text-yellow-500" />;
      case 'partlyCloudy':
        return <Cloud size={size} className="text-gray-400" />;
      case 'cloudy':
        return <Cloud size={size} className="text-gray-500" />;
      case 'rainy':
        return <CloudRain size={size} className="text-blue-500" />;
      case 'stormy':
        return <CloudRain size={size} className="text-purple-500" />;
      default:
        return <Sun size={size} className="text-yellow-500" />;
    }
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Today's weather (first forecast day)
  const today = weatherForecast[0];
  
  // Last temperature reading
  const currentTemp = sensorData.temperature[sensorData.temperature.length - 1]?.value || 0;
  
  // Last humidity reading
  const currentHumidity = sensorData.humidity[sensorData.humidity.length - 1]?.value || 0;
  
  // Last wind speed reading
  const currentWindSpeed = sensorData.windSpeed[sensorData.windSpeed.length - 1]?.value || 0;
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Weather Forecast</h1>
        <p className="text-gray-600">Monitor weather conditions for optimal farm planning.</p>
      </div>
      
      {/* Current weather summary */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg shadow-md p-6 mb-6 text-white">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-4">
              <div className="mr-4">
                {getWeatherIcon(today.condition, 48)}
              </div>
              <div>
                <h2 className="text-3xl font-bold">{currentTemp}°C</h2>
                <p className="text-blue-100">{formatDate(today.date)}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-blue-100 text-sm">Humidity</p>
                <p className="font-semibold flex items-center">
                  <Cloud size={16} className="mr-1" /> {currentHumidity}%
                </p>
              </div>
              <div>
                <p className="text-blue-100 text-sm">Wind Speed</p>
                <p className="font-semibold flex items-center">
                  <Wind size={16} className="mr-1" /> {currentWindSpeed} km/h
                </p>
              </div>
              <div>
                <p className="text-blue-100 text-sm">Precipitation</p>
                <p className="font-semibold flex items-center">
                  <CloudRain size={16} className="mr-1" /> {today.precipitation} mm
                </p>
              </div>
            </div>
          </div>
          
          <div className="hidden md:block bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <h3 className="font-semibold mb-2">Farm Weather Impact</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="bg-yellow-400 rounded-full w-2 h-2 mt-1.5 mr-2"></span>
                {today.precipitation > 0 
                  ? "Expected rainfall may reduce irrigation needs" 
                  : "Dry conditions may increase irrigation requirements"}
              </li>
              <li className="flex items-start">
                <span className="bg-green-400 rounded-full w-2 h-2 mt-1.5 mr-2"></span>
                {currentTemp > 30 
                  ? "High temperatures may stress crops; monitor closely"
                  : "Temperature favorable for crop development"}
              </li>
              <li className="flex items-start">
                <span className="bg-blue-400 rounded-full w-2 h-2 mt-1.5 mr-2"></span>
                {currentWindSpeed > 20 
                  ? "Strong winds may affect spray applications"
                  : "Wind conditions suitable for field operations"}
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Weekly forecast */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="p-4 bg-blue-600 text-white">
          <h3 className="font-semibold">7-Day Forecast</h3>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7">
          {weatherForecast.map((day, index) => (
            <div 
              key={index} 
              className={`p-4 ${index < weatherForecast.length - 1 ? 'border-b sm:border-b-0 sm:border-r' : ''} ${index === 0 ? 'bg-blue-50' : ''}`}
            >
              <p className="font-medium mb-2">{new Date(day.date).toLocaleDateString(undefined, { weekday: 'short' })}</p>
              <div className="flex justify-between items-center mb-2">
                <div className="text-center">
                  {getWeatherIcon(day.condition)}
                </div>
                <div className="text-right">
                  <p className="text-red-500 font-medium">{day.temperature.max}°</p>
                  <p className="text-blue-500">{day.temperature.min}°</p>
                </div>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span className="flex items-center">
                  <CloudRain size={12} className="mr-1" /> {day.precipitation}mm
                </span>
                <span className="flex items-center">
                  <Wind size={12} className="mr-1" /> {day.windSpeed}km/h
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Weather alerts and advisories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-4 bg-amber-600 text-white">
            <h3 className="font-semibold">Weather Alerts</h3>
          </div>
          
          <div className="p-4">
            {weatherForecast.some(day => day.precipitation > 20) ? (
              <div className="mb-3 p-3 bg-amber-50 border-l-4 border-amber-500 rounded-sm">
                <h4 className="font-medium text-amber-700">Heavy Rain Alert</h4>
                <p className="text-sm text-gray-700 mt-1">
                  Heavy rainfall expected in the next 72 hours. Consider rescheduling outdoor activities.
                </p>
              </div>
            ) : (
              <div className="mb-3 p-3 bg-green-50 border-l-4 border-green-500 rounded-sm">
                <h4 className="font-medium text-green-700">No Weather Alerts</h4>
                <p className="text-sm text-gray-700 mt-1">
                  No significant weather events expected in the next 7 days.
                </p>
              </div>
            )}
            
            {weatherForecast.some(day => day.temperature.max > 32) && (
              <div className="p-3 bg-red-50 border-l-4 border-red-500 rounded-sm">
                <h4 className="font-medium text-red-700">Heat Advisory</h4>
                <p className="text-sm text-gray-700 mt-1">
                  Temperatures may exceed 32°C in the coming days. Ensure proper irrigation to prevent heat stress on crops.
                </p>
              </div>
            )}
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-4 bg-green-600 text-white">
            <h3 className="font-semibold">Weather Impact Analysis</h3>
          </div>
          
          <div className="p-4">
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">Crop Growth Conditions</h4>
              <div className="flex items-center mb-2">
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '85%' }}></div>
                </div>
                <span className="text-sm ml-2">85%</span>
              </div>
              <p className="text-sm text-gray-600">
                Current weather conditions are favorable for crop development.
              </p>
            </div>
            
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">Field Work Suitability</h4>
              <div className="grid grid-cols-7 gap-1 mb-2">
                {weatherForecast.map((day, index) => {
                  // Define suitability based on precipitation and wind
                  const suitable = day.precipitation < 5 && day.windSpeed < 15;
                  const marginal = day.precipitation < 10 && day.windSpeed < 20;
                  
                  let bgColor = 'bg-gray-200';
                  if (suitable) bgColor = 'bg-green-500';
                  else if (marginal) bgColor = 'bg-amber-500';
                  else bgColor = 'bg-red-500';
                  
                  return (
                    <div key={index} className="flex flex-col items-center">
                      <div className={`w-6 h-6 rounded-full ${bgColor}`}></div>
                      <div className="text-xs mt-1">
                        {new Date(day.date).toLocaleDateString(undefined, { weekday: 'short' }).substring(0, 2)}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between text-xs text-gray-600">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                  <span>Suitable</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-amber-500 mr-1"></div>
                  <span>Marginal</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                  <span>Unsuitable</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Season Progress</h4>
              <div className="relative pt-1">
                <div className="flex mb-2 items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold inline-block py-1 px-2 rounded-full bg-green-200 text-green-800">
                      Spring Season: 65%
                    </span>
                  </div>
                </div>
                <div className="flex h-2 mb-4 overflow-hidden text-xs bg-green-200 rounded">
                  <div style={{ width: "65%" }} className="flex flex-col justify-center text-center text-white bg-green-500 shadow-none"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeatherDashboard;