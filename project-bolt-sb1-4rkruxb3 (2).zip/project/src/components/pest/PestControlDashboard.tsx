import React from 'react';
import { Bug, AlertTriangle, Map, Camera, Thermometer, Wind } from 'lucide-react';
import { crops, sensorData } from '../../utils/mockData';

const PestControlDashboard: React.FC = () => {
  const pestRiskLevel = (temperature: number, humidity: number) => {
    if (temperature > 25 && humidity > 70) return 'High';
    if (temperature > 20 && humidity > 60) return 'Medium';
    return 'Low';
  };
  
  const currentTemp = sensorData.temperature[sensorData.temperature.length - 1].value;
  const currentHumidity = sensorData.humidity[sensorData.humidity.length - 1].value;
  const riskLevel = pestRiskLevel(currentTemp, currentHumidity);
  
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'High':
        return 'text-red-600';
      case 'Medium':
        return 'text-amber-600';
      case 'Low':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };
  
  const mockDetections = [
    {
      id: 1,
      pest: 'Aphids',
      location: 'North Field',
      severity: 'Medium',
      detectedAt: '2024-03-15T10:30:00Z',
      affectedCrop: 'Wheat',
      status: 'Monitoring'
    },
    {
      id: 2,
      pest: 'Corn Borers',
      location: 'East Field',
      severity: 'High',
      detectedAt: '2024-03-14T15:45:00Z',
      affectedCrop: 'Corn',
      status: 'Treatment Scheduled'
    },
    {
      id: 3,
      pest: 'Spider Mites',
      location: 'Greenhouse 1',
      severity: 'Low',
      detectedAt: '2024-03-13T09:15:00Z',
      affectedCrop: 'Tomatoes',
      status: 'Treated'
    }
  ];
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Pest Control Management</h1>
        <p className="text-gray-600">Monitor and manage pest threats across your farm.</p>
      </div>
      
      {/* Risk Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-800">Current Risk Level</h3>
            <AlertTriangle size={20} className={getRiskColor(riskLevel)} />
          </div>
          <p className={`text-2xl font-bold ${getRiskColor(riskLevel)}`}>{riskLevel}</p>
          <div className="mt-2 text-sm text-gray-500">
            <p>Temperature: {currentTemp}°C</p>
            <p>Humidity: {currentHumidity}%</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-800">Active Detections</h3>
            <Bug size={20} className="text-amber-600" />
          </div>
          <p className="text-2xl font-bold text-gray-800">{mockDetections.length}</p>
          <div className="mt-2 text-sm text-gray-500">
            <p>High Severity: {mockDetections.filter(d => d.severity === 'High').length}</p>
            <p>Medium Severity: {mockDetections.filter(d => d.severity === 'Medium').length}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-800">Monitored Area</h3>
            <Map size={20} className="text-green-600" />
          </div>
          <p className="text-2xl font-bold text-gray-800">
            {crops.reduce((acc, crop) => acc + crop.area, 0)} hectares
          </p>
          <p className="mt-2 text-sm text-gray-500">
            {crops.length} active crop zones under surveillance
          </p>
        </div>
      </div>
      
      {/* Active Detections */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="p-4 bg-amber-600 text-white flex justify-between items-center">
          <h3 className="font-semibold">Active Pest Detections</h3>
          <button className="px-3 py-1 bg-white text-amber-600 rounded text-sm hover:bg-amber-50">
            View All Reports
          </button>
        </div>
        
        <div className="divide-y">
          {mockDetections.map(detection => (
            <div key={detection.id} className="p-4 hover:bg-amber-50 transition-colors duration-200">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium">{detection.pest}</h4>
                  <p className="text-sm text-gray-500">{detection.location}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  detection.severity === 'High'
                    ? 'bg-red-100 text-red-700'
                    : detection.severity === 'Medium'
                    ? 'bg-amber-100 text-amber-700'
                    : 'bg-green-100 text-green-700'
                }`}>
                  {detection.severity} Risk
                </span>
              </div>
              
              <div className="flex items-center text-sm text-gray-500 mb-2">
                <Camera size={16} className="mr-1" />
                <span>Detected: {new Date(detection.detectedAt).toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">
                  Affecting: <span className="font-medium">{detection.affectedCrop}</span>
                </span>
                <span className={`text-sm ${
                  detection.status === 'Treated'
                    ? 'text-green-600'
                    : detection.status === 'Treatment Scheduled'
                    ? 'text-blue-600'
                    : 'text-amber-600'
                }`}>
                  {detection.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Prevention Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-4 bg-green-600 text-white">
            <h3 className="font-semibold">Prevention Recommendations</h3>
          </div>
          
          <div className="p-4">
            <div className="mb-4 p-3 bg-blue-50 border-l-4 border-blue-500 rounded-sm">
              <h4 className="font-medium text-blue-700">Environmental Control</h4>
              <div className="mt-2 space-y-2">
                <div className="flex items-center">
                  <Thermometer size={16} className="text-blue-500 mr-2" />
                  <p className="text-sm text-gray-700">
                    Maintain greenhouse temperature below 25°C to reduce pest breeding
                  </p>
                </div>
                <div className="flex items-center">
                  <Wind size={16} className="text-blue-500 mr-2" />
                  <p className="text-sm text-gray-700">
                    Improve ventilation in high-humidity areas
                  </p>
                </div>
              </div>
            </div>
            
            <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded-sm">
              <h4 className="font-medium text-green-700">Cultural Practices</h4>
              <ul className="mt-2 space-y-2 text-sm text-gray-700">
                <li>• Regular monitoring of plant health and pest presence</li>
                <li>• Maintain proper spacing between plants</li>
                <li>• Remove and dispose of infected plant material</li>
                <li>• Implement crop rotation strategies</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-4 bg-blue-600 text-white">
            <h3 className="font-semibold">Treatment Schedule</h3>
          </div>
          
          <div className="p-4">
            <div className="mb-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-gray-800">Upcoming Treatments</h4>
                <button className="text-sm text-blue-600 hover:text-blue-800">
                  View Calendar
                </button>
              </div>
              
              <div className="mt-4 space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">Corn Field - Pest Control</p>
                    <p className="text-sm text-gray-500">Scheduled for tomorrow, 8:00 AM</p>
                  </div>
                  <button className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm hover:bg-blue-200">
                    View Details
                  </button>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">Wheat Zone - Preventive Spray</p>
                    <p className="text-sm text-gray-500">Scheduled for Mar 18, 9:30 AM</p>
                  </div>
                  <button className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm hover:bg-blue-200">
                    View Details
                  </button>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="font-medium text-gray-800 mb-3">Treatment History</h4>
              <div className="space-y-3">
                <div className="flex items-center text-sm">
                  <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-gray-500">Mar 12 - Tomato Greenhouse Treatment</span>
                </div>
                <div className="flex items-center text-sm">
                  <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-gray-500">Mar 10 - Soybean Field Inspection</span>
                </div>
                <div className="flex items-center text-sm">
                  <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-gray-500">Mar 8 - Corn Field Prevention</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PestControlDashboard;