export interface SensorReading {
  id: string;
  timestamp: string;
  value: number;
  type: 'temperature' | 'humidity' | 'soilMoisture' | 'rainfall' | 'windSpeed' | 'soilNutrient';
  unit: string;
}

export interface WeatherForecast {
  date: string;
  condition: 'sunny' | 'partlyCloudy' | 'cloudy' | 'rainy' | 'stormy';
  temperature: {
    min: number;
    max: number;
  };
  precipitation: number;
  humidity: number;
  windSpeed: number;
}

export interface Crop {
  id: string;
  name: string;
  type: string;
  plantingDate: string;
  expectedHarvestDate: string;
  healthIndex: number; // 0-100
  area: number;
  unit: 'hectare' | 'acre';
}

export interface Alert {
  id: string;
  type: 'warning' | 'critical' | 'info';
  message: string;
  timestamp: string;
  read: boolean;
  relatedTo: 'crop' | 'weather' | 'soil' | 'irrigation' | 'pest';
}

export interface SoilHealth {
  id: string;
  location: string;
  ph: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  organicMatter: number;
  lastUpdated: string;
}

export interface IrrigationZone {
  id: string;
  name: string;
  status: 'active' | 'scheduled' | 'inactive';
  moistureLevel: number;
  lastIrrigated: string;
  scheduledFor?: string;
  crops: string[];
}