import { 
  SensorReading, 
  WeatherForecast, 
  Crop, 
  Alert, 
  SoilHealth,
  IrrigationZone
} from '../types';

// Mock sensor data for the last 24 hours (with readings every hour)
export const generateSensorData = (type: SensorReading['type'], min: number, max: number): SensorReading[] => {
  const readings: SensorReading[] = [];
  const now = new Date();
  
  let unit = '';
  switch(type) {
    case 'temperature':
      unit = '°C';
      break;
    case 'humidity':
    case 'soilMoisture':
      unit = '%';
      break;
    case 'rainfall':
      unit = 'mm';
      break;
    case 'windSpeed':
      unit = 'km/h';
      break;
    case 'soilNutrient':
      unit = 'ppm';
      break;
  }

  for (let i = 0; i < 24; i++) {
    const timestamp = new Date(now.getTime() - (23 - i) * 60 * 60 * 1000).toISOString();
    const value = parseFloat((Math.random() * (max - min) + min).toFixed(1));
    
    readings.push({
      id: `${type}-${i}`,
      timestamp,
      value,
      type,
      unit
    });
  }
  
  return readings;
};

export const sensorData = {
  temperature: generateSensorData('temperature', 18, 35),
  humidity: generateSensorData('humidity', 40, 90),
  soilMoisture: generateSensorData('soilMoisture', 20, 80),
  rainfall: generateSensorData('rainfall', 0, 10),
  windSpeed: generateSensorData('windSpeed', 0, 25),
  soilNutrient: generateSensorData('soilNutrient', 100, 500)
};

// Weather forecast for the next 7 days
export const weatherForecast: WeatherForecast[] = [
  {
    date: new Date(Date.now() + 86400000 * 0).toISOString().split('T')[0],
    condition: 'sunny',
    temperature: { min: 20, max: 32 },
    precipitation: 0,
    humidity: 45,
    windSpeed: 5
  },
  {
    date: new Date(Date.now() + 86400000 * 1).toISOString().split('T')[0],
    condition: 'partlyCloudy',
    temperature: { min: 22, max: 30 },
    precipitation: 0,
    humidity: 50,
    windSpeed: 8
  },
  {
    date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    condition: 'cloudy',
    temperature: { min: 21, max: 28 },
    precipitation: 10,
    humidity: 65,
    windSpeed: 10
  },
  {
    date: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    condition: 'rainy',
    temperature: { min: 19, max: 26 },
    precipitation: 25,
    humidity: 80,
    windSpeed: 15
  },
  {
    date: new Date(Date.now() + 86400000 * 4).toISOString().split('T')[0],
    condition: 'partlyCloudy',
    temperature: { min: 20, max: 29 },
    precipitation: 5,
    humidity: 60,
    windSpeed: 7
  },
  {
    date: new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0],
    condition: 'sunny',
    temperature: { min: 22, max: 31 },
    precipitation: 0,
    humidity: 45,
    windSpeed: 6
  },
  {
    date: new Date(Date.now() + 86400000 * 6).toISOString().split('T')[0],
    condition: 'sunny',
    temperature: { min: 23, max: 33 },
    precipitation: 0,
    humidity: 40,
    windSpeed: 5
  }
];

// Crops data
export const crops: Crop[] = [
  {
    id: 'crop-1',
    name: 'Wheat',
    type: 'Grain',
    plantingDate: '2024-02-10',
    expectedHarvestDate: '2024-06-15',
    healthIndex: 85,
    area: 25,
    unit: 'hectare'
  },
  {
    id: 'crop-2',
    name: 'Corn',
    type: 'Grain',
    plantingDate: '2024-03-20',
    expectedHarvestDate: '2024-08-10',
    healthIndex: 92,
    area: 15,
    unit: 'hectare'
  },
  {
    id: 'crop-3',
    name: 'Soybeans',
    type: 'Legume',
    plantingDate: '2024-04-05',
    expectedHarvestDate: '2024-09-25',
    healthIndex: 78,
    area: 20,
    unit: 'hectare'
  },
  {
    id: 'crop-4',
    name: 'Tomatoes',
    type: 'Vegetable',
    plantingDate: '2024-03-15',
    expectedHarvestDate: '2024-07-20',
    healthIndex: 65,
    area: 5,
    unit: 'hectare'
  }
];

// Alerts
export const alerts: Alert[] = [
  {
    id: 'alert-1',
    type: 'warning',
    message: 'Soil moisture levels dropping below optimal range in wheat fields.',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    read: false,
    relatedTo: 'soil'
  },
  {
    id: 'alert-2',
    type: 'critical',
    message: 'Potential pest infestation detected in tomato crops.',
    timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
    read: false,
    relatedTo: 'pest'
  },
  {
    id: 'alert-3',
    type: 'info',
    message: 'Weather forecast predicts rain in the next 48 hours. Consider adjusting irrigation schedule.',
    timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
    read: true,
    relatedTo: 'weather'
  },
  {
    id: 'alert-4',
    type: 'warning',
    message: 'Nitrogen levels low in soybean fields.',
    timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
    read: true,
    relatedTo: 'soil'
  }
];

// Soil health data for different zones
export const soilHealth: SoilHealth[] = [
  {
    id: 'soil-1',
    location: 'North Field',
    ph: 6.5,
    nitrogen: 42,
    phosphorus: 35,
    potassium: 65,
    organicMatter: 3.2,
    lastUpdated: new Date(Date.now() - 86400000).toISOString()
  },
  {
    id: 'soil-2',
    location: 'South Field',
    ph: 7.2,
    nitrogen: 38,
    phosphorus: 40,
    potassium: 70,
    organicMatter: 2.8,
    lastUpdated: new Date(Date.now() - 86400000 * 2).toISOString()
  },
  {
    id: 'soil-3',
    location: 'East Field',
    ph: 5.8,
    nitrogen: 30,
    phosphorus: 28,
    potassium: 55,
    organicMatter: 2.5,
    lastUpdated: new Date(Date.now() - 86400000 * 3).toISOString()
  },
  {
    id: 'soil-4',
    location: 'West Field',
    ph: 6.8,
    nitrogen: 45,
    phosphorus: 38,
    potassium: 60,
    organicMatter: 3.5,
    lastUpdated: new Date(Date.now() - 86400000 * 1.5).toISOString()
  }
];

// Irrigation zones
export const irrigationZones: IrrigationZone[] = [
  {
    id: 'zone-1',
    name: 'Wheat Zone',
    status: 'active',
    moistureLevel: 65,
    lastIrrigated: new Date(Date.now() - 3600000 * 5).toISOString(),
    crops: ['crop-1']
  },
  {
    id: 'zone-2',
    name: 'Corn Zone',
    status: 'scheduled',
    moistureLevel: 45,
    lastIrrigated: new Date(Date.now() - 3600000 * 48).toISOString(),
    scheduledFor: new Date(Date.now() + 3600000 * 6).toISOString(),
    crops: ['crop-2']
  },
  {
    id: 'zone-3',
    name: 'Soybean Zone',
    status: 'inactive',
    moistureLevel: 70,
    lastIrrigated: new Date(Date.now() - 3600000 * 12).toISOString(),
    crops: ['crop-3']
  },
  {
    id: 'zone-4',
    name: 'Tomato Zone',
    status: 'scheduled',
    moistureLevel: 55,
    lastIrrigated: new Date(Date.now() - 3600000 * 30).toISOString(),
    scheduledFor: new Date(Date.now() + 3600000 * 2).toISOString(),
    crops: ['crop-4']
  }
];