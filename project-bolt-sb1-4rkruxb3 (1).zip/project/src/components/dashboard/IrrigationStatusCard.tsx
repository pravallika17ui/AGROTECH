import React from 'react';
import { Droplets, Clock, Check, AlertCircle } from 'lucide-react';
import { IrrigationZone } from '../../types';

interface IrrigationStatusCardProps {
  zones: IrrigationZone[];
}

const IrrigationStatusCard: React.FC<IrrigationStatusCardProps> = ({ zones }) => {
  const getStatusIcon = (status: IrrigationZone['status']) => {
    switch (status) {
      case 'active':
        return <Droplets size={16} className="text-blue-500" />;
      case 'scheduled':
        return <Clock size={16} className="text-amber-500" />;
      case 'inactive':
        return <Check size={16} className="text-green-500" />;
      default:
        return <AlertCircle size={16} className="text-gray-500" />;
    }
  };
  
  const getStatusText = (status: IrrigationZone['status']) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'scheduled':
        return 'Scheduled';
      case 'inactive':
        return 'Inactive';
      default:
        return 'Unknown';
    }
  };
  
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getMoistureColor = (level: number) => {
    if (level >= 70) return 'bg-blue-500';
    if (level >= 40) return 'bg-blue-400';
    return 'bg-amber-500';
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-blue-600 text-white">
        <h3 className="font-semibold">Irrigation Status</h3>
      </div>
      
      <div className="divide-y">
        {zones.map(zone => (
          <div key={zone.id} className="p-4 hover:bg-blue-50 transition-colors duration-200">
            <div className="flex justify-between mb-2">
              <h4 className="font-medium">{zone.name}</h4>
              <div className="flex items-center">
                {getStatusIcon(zone.status)}
                <span className="text-sm ml-1">{getStatusText(zone.status)}</span>
              </div>
            </div>
            
            <div className="flex items-center mb-2">
              <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${getMoistureColor(zone.moistureLevel)}`}
                  style={{ width: `${zone.moistureLevel}%` }}
                ></div>
              </div>
              <span className="ml-3 text-sm">{zone.moistureLevel}% Moisture</span>
            </div>
            
            <div className="text-xs text-gray-500">
              {zone.status === 'active' && (
                <p>Currently irrigating since {formatTime(zone.lastIrrigated)}</p>
              )}
              {zone.status === 'scheduled' && zone.scheduledFor && (
                <p>Scheduled for today at {formatTime(zone.scheduledFor)}</p>
              )}
              {zone.status === 'inactive' && (
                <p>Last irrigated: {formatTime(zone.lastIrrigated)}</p>
              )}
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-3 bg-gray-50 text-center">
        <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
          Manage irrigation zones
        </button>
      </div>
    </div>
  );
};

export default IrrigationStatusCard;