import React from 'react';
import { Plane as Plant, Calendar, ArrowRight } from 'lucide-react';
import { Crop } from '../../types';

interface CropHealthCardProps {
  crops: Crop[];
}

const CropHealthCard: React.FC<CropHealthCardProps> = ({ crops }) => {
  const getHealthColor = (healthIndex: number) => {
    if (healthIndex >= 80) return 'bg-green-500';
    if (healthIndex >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-green-600 text-white">
        <h3 className="font-semibold">Crop Health Status</h3>
      </div>
      
      <div className="divide-y">
        {crops.map(crop => (
          <div key={crop.id} className="p-4 hover:bg-green-50 transition-colors duration-200">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center">
                <Plant size={18} className="text-green-600 mr-2" />
                <h4 className="font-medium">{crop.name}</h4>
              </div>
              <span className="text-sm text-gray-500">{crop.area} {crop.unit}</span>
            </div>
            
            <div className="flex items-center mb-2">
              <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${getHealthColor(crop.healthIndex)}`}
                  style={{ width: `${crop.healthIndex}%` }}
                ></div>
              </div>
              <span className="ml-3 font-semibold text-sm">{crop.healthIndex}%</span>
            </div>
            
            <div className="flex items-center text-xs text-gray-500">
              <Calendar size={14} className="mr-1" />
              <span>Planted: {formatDate(crop.plantingDate)}</span>
              <ArrowRight size={12} className="mx-1" />
              <span>Harvest: {formatDate(crop.expectedHarvestDate)}</span>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-3 bg-gray-50 text-center">
        <button className="text-sm text-green-600 hover:text-green-800 font-medium">
          View detailed crop analysis
        </button>
      </div>
    </div>
  );
};

export default CropHealthCard;