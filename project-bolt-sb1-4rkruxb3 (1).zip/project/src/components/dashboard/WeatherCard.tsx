import React from 'react';
import { CloudRain, Sun, Cloud, CloudLightning } from 'lucide-react';
import { WeatherForecast } from '../../types';

interface WeatherCardProps {
  forecast: WeatherForecast[];
}

const WeatherCard: React.FC<WeatherCardProps> = ({ forecast }) => {
  const getWeatherIcon = (condition: WeatherForecast['condition']) => {
    switch (condition) {
      case 'sunny':
        return <Sun size={24} className="text-yellow-500" />;
      case 'partlyCloudy':
        return <Cloud size={24} className="text-gray-400" />;
      case 'cloudy':
        return <Cloud size={24} className="text-gray-500" />;
      case 'rainy':
        return <CloudRain size={24} className="text-blue-500" />;
      case 'stormy':
        return <CloudLightning size={24} className="text-purple-500" />;
      default:
        return <Sun size={24} className="text-yellow-500" />;
    }
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-blue-600 text-white">
        <h3 className="font-semibold">Weather Forecast</h3>
      </div>
      
      <div className="p-1">
        <div className="overflow-x-auto">
          <div className="flex space-x-2 p-2 min-w-max">
            {forecast.map((day, index) => (
              <div 
                key={index} 
                className={`flex flex-col items-center p-3 rounded-lg min-w-[90px] ${
                  index === 0 ? 'bg-blue-50 border border-blue-100' : 'hover:bg-gray-50'
                }`}
              >
                <span className="text-xs font-medium text-gray-500">{formatDate(day.date)}</span>
                <div className="my-2">{getWeatherIcon(day.condition)}</div>
                <div className="flex items-center justify-between space-x-2">
                  <span className="text-xs font-bold text-red-500">{day.temperature.max}°</span>
                  <span className="text-xs text-blue-500">{day.temperature.min}°</span>
                </div>
                <div className="mt-1 text-xs text-gray-500">{day.precipitation}mm</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeatherCard;