import React from 'react';
import { Microscope } from 'lucide-react';
import { SoilHealth } from '../../types';

interface SoilHealthCardProps {
  soilData: SoilHealth[];
}

const SoilHealthCard: React.FC<SoilHealthCardProps> = ({ soilData }) => {
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  const getPhColor = (ph: number) => {
    if (ph >= 6.0 && ph <= 7.5) return 'text-green-600';
    if (ph >= 5.5 && ph < 6.0) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  const getNutrientLevel = (value: number) => {
    if (value >= 40) return 'High';
    if (value >= 25) return 'Medium';
    return 'Low';
  };
  
  const getNutrientColor = (value: number) => {
    if (value >= 40) return 'text-green-600';
    if (value >= 25) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-4 bg-amber-600 text-white">
        <h3 className="font-semibold">Soil Health Analysis</h3>
      </div>
      
      <div className="divide-y">
        {soilData.map(soil => (
          <div key={soil.id} className="p-4 hover:bg-amber-50 transition-colors duration-200">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center">
                <Microscope size={18} className="text-amber-600 mr-2" />
                <h4 className="font-medium">{soil.location}</h4>
              </div>
              <span className="text-xs text-gray-500">
                Updated: {formatDate(soil.lastUpdated)}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-2">
              <div>
                <div className="flex justify-between">
                  <span className="text-xs text-gray-500">pH Level</span>
                  <span className={`text-sm font-medium ${getPhColor(soil.ph)}`}>{soil.ph}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-gray-500">Organic Matter</span>
                  <span className="text-sm font-medium">{soil.organicMatter}%</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between">
                  <span className="text-xs text-gray-500">Nitrogen</span>
                  <span className={`text-sm font-medium ${getNutrientColor(soil.nitrogen)}`}>
                    {getNutrientLevel(soil.nitrogen)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-gray-500">Phosphorus</span>
                  <span className={`text-sm font-medium ${getNutrientColor(soil.phosphorus)}`}>
                    {getNutrientLevel(soil.phosphorus)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-gray-500">Potassium</span>
                  <span className={`text-sm font-medium ${getNutrientColor(soil.potassium)}`}>
                    {getNutrientLevel(soil.potassium)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-3 bg-gray-50 text-center">
        <button className="text-sm text-amber-600 hover:text-amber-800 font-medium">
          View detailed soil analysis
        </button>
      </div>
    </div>
  );
};

export default SoilHealthCard;