import React, { useState } from 'react';
import WeatherCard from './WeatherCard';
import SensorChart from './SensorChart';
import CropHealthCard from './CropHealthCard';
import IrrigationStatusCard from './IrrigationStatusCard';
import SoilHealthCard from './SoilHealthCard';
import { 
  weatherForecast, 
  sensorData, 
  crops, 
  irrigationZones, 
  soilHealth, 
  alerts 
} from '../../utils/mockData';

const Dashboard: React.FC = () => {
  const [activeSection] = useState('overview');
  
  // Count unread alerts
  const unreadAlertsCount = alerts.filter(alert => !alert.read).length;
  
  // Get latest temp reading
  const latestTemp = sensorData.temperature[sensorData.temperature.length - 1]?.value || 0;
  const latestHumidity = sensorData.humidity[sensorData.humidity.length - 1]?.value || 0;
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600">Welcome back to your farm management system.</p>
      </div>
      
      {/* Stats summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-green-500">
          <span className="text-sm text-gray-500">Current Temperature</span>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-gray-800">{latestTemp}°C</span>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-blue-500">
          <span className="text-sm text-gray-500">Humidity</span>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-gray-800">{latestHumidity}%</span>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-amber-500">
          <span className="text-sm text-gray-500">Active Irrigation Zones</span>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-gray-800">
              {irrigationZones.filter(z => z.status === 'active').length}/{irrigationZones.length}
            </span>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-red-500">
          <span className="text-sm text-gray-500">Alerts</span>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-gray-800">{unreadAlertsCount}</span>
            <span className="ml-1 text-sm text-gray-500 mb-0.5">unread</span>
          </div>
        </div>
      </div>
      
      {/* Navigation tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              className={`
                py-2 px-1 border-b-2 font-medium text-sm 
                ${activeSection === 'overview' 
                  ? 'border-green-500 text-green-600' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
              `}
            >
              Overview
            </button>
            <button
              className={`
                py-2 px-1 border-b-2 font-medium text-sm border-transparent 
                text-gray-500 hover:text-gray-700 hover:border-gray-300
              `}
            >
              Detailed Analysis
            </button>
            <button
              className={`
                py-2 px-1 border-b-2 font-medium text-sm border-transparent 
                text-gray-500 hover:text-gray-700 hover:border-gray-300
              `}
            >
              Reports
            </button>
          </nav>
        </div>
      </div>
      
      {/* Main dashboard content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="mb-6">
            <WeatherCard forecast={weatherForecast} />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <SensorChart 
              data={sensorData.temperature}
              title="Temperature (24h)"
              color="bg-red-600"
            />
            <SensorChart 
              data={sensorData.humidity}
              title="Humidity (24h)"
              color="bg-blue-600"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <SensorChart 
              data={sensorData.soilMoisture}
              title="Soil Moisture (24h)"
              color="bg-amber-600"
            />
            <SensorChart 
              data={sensorData.rainfall}
              title="Rainfall (24h)"
              color="bg-blue-600"
            />
          </div>
        </div>
        
        <div className="space-y-6">
          <CropHealthCard crops={crops} />
          <IrrigationStatusCard zones={irrigationZones} />
          <SoilHealthCard soilData={soilHealth} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;