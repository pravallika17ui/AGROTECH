import React, { useState } from 'react';
import { Plane as Plant, Calendar, TrendingUp, AlertTriangle, Droplets, Sun } from 'lucide-react';
import { crops, sensorData, weatherForecast } from '../../utils/mockData';

const CropsDashboard: React.FC = () => {
  const [selectedCrop, setSelectedCrop] = useState(crops[0]);
  
  const getGrowthStage = (plantDate: string, harvestDate: string) => {
    const total = new Date(harvestDate).getTime() - new Date(plantDate).getTime();
    const current = Date.now() - new Date(plantDate).getTime();
    const percentage = (current / total) * 100;
    
    if (percentage < 20) return 'Germination';
    if (percentage < 40) return 'Vegetative';
    if (percentage < 60) return 'Flowering';
    if (percentage < 80) return 'Fruit Development';
    return 'Maturation';
  };
  
  const getOptimalConditions = (cropType: string) => {
    switch (cropType) {
      case 'Grain':
        return {
          temperature: '20-25°C',
          humidity: '50-70%',
          soilMoisture: '60-80%'
        };
      case 'Legume':
        return {
          temperature: '18-24°C',
          humidity: '60-70%',
          soilMoisture: '50-70%'
        };
      case 'Vegetable':
        return {
          temperature: '18-26°C',
          humidity: '65-75%',
          soilMoisture: '70-80%'
        };
      default:
        return {
          temperature: '20-25°C',
          humidity: '60-70%',
          soilMoisture: '60-80%'
        };
    }
  };
  
  const getHealthStatus = (healthIndex: number) => {
    if (healthIndex >= 80) return { text: 'Excellent', color: 'text-green-600' };
    if (healthIndex >= 60) return { text: 'Good', color: 'text-blue-600' };
    return { text: 'Needs Attention', color: 'text-amber-600' };
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  const getDaysSincePlanting = (plantDate: string) => {
    const days = Math.floor((Date.now() - new Date(plantDate).getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };
  
  const getDaysUntilHarvest = (harvestDate: string) => {
    const days = Math.floor((new Date(harvestDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    return days;
  };
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Crop Management</h1>
        <p className="text-gray-600">Monitor and manage your crops' growth and health.</p>
      </div>
      
      {/* Crop Selection */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {crops.map(crop => (
          <button
            key={crop.id}
            onClick={() => setSelectedCrop(crop)}
            className={`p-4 rounded-lg shadow-md transition-colors duration-200 ${
              selectedCrop.id === crop.id
                ? 'bg-green-600 text-white'
                : 'bg-white hover:bg-green-50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Plant size={20} className={selectedCrop.id === crop.id ? 'text-white' : 'text-green-600'} />
              <span className={`text-xs ${
                selectedCrop.id === crop.id ? 'text-green-100' : 'text-gray-500'
              }`}>{crop.area} {crop.unit}</span>
            </div>
            <h3 className="font-medium">{crop.name}</h3>
            <p className={`text-sm ${
              selectedCrop.id === crop.id ? 'text-green-100' : 'text-gray-500'
            }`}>{crop.type}</p>
          </button>
        ))}
      </div>
      
      {selectedCrop && (
        <>
          {/* Crop Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-gray-800">Growth Timeline</h3>
                <Calendar size={20} className="text-green-600" />
              </div>
              <div className="space-y-2">
                <div>
                  <p className="text-sm text-gray-500">Planted</p>
                  <p className="font-medium">{formatDate(selectedCrop.plantingDate)}</p>
                  <p className="text-sm text-gray-500">{getDaysSincePlanting(selectedCrop.plantingDate)} days ago</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Expected Harvest</p>
                  <p className="font-medium">{formatDate(selectedCrop.expectedHarvestDate)}</p>
                  <p className="text-sm text-gray-500">in {getDaysUntilHarvest(selectedCrop.expectedHarvestDate)} days</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-gray-800">Growth Stage</h3>
                <TrendingUp size={20} className="text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">
                  {getGrowthStage(selectedCrop.plantingDate, selectedCrop.expectedHarvestDate)}
                </p>
                <div className="mt-4">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{
                        width: `${(getDaysSincePlanting(selectedCrop.plantingDate) /
                          (getDaysSincePlanting(selectedCrop.plantingDate) +
                            getDaysUntilHarvest(selectedCrop.expectedHarvestDate))) *
                          100}%`
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-gray-800">Health Status</h3>
                <AlertTriangle size={20} className="text-green-600" />
              </div>
              <div>
                <p className={`text-2xl font-bold ${getHealthStatus(selectedCrop.healthIndex).color}`}>
                  {getHealthStatus(selectedCrop.healthIndex).text}
                </p>
                <div className="mt-4">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        selectedCrop.healthIndex >= 80
                          ? 'bg-green-500'
                          : selectedCrop.healthIndex >= 60
                          ? 'bg-blue-500'
                          : 'bg-amber-500'
                      }`}
                      style={{ width: `${selectedCrop.healthIndex}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">Health Index: {selectedCrop.healthIndex}%</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Environmental Conditions */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
            <div className="p-4 bg-green-600 text-white">
              <h3 className="font-semibold">Environmental Conditions</h3>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <div className="flex items-center mb-2">
                    <Sun size={20} className="text-amber-500 mr-2" />
                    <h4 className="font-medium">Temperature</h4>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Current</p>
                      <p className="text-xl font-bold">
                        {sensorData.temperature[sensorData.temperature.length - 1].value}°C
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Optimal Range</p>
                      <p className="text-green-600">
                        {getOptimalConditions(selectedCrop.type).temperature}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <Cloud size={20} className="text-blue-500 mr-2" />
                    <h4 className="font-medium">Humidity</h4>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Current</p>
                      <p className="text-xl font-bold">
                        {sensorData.humidity[sensorData.humidity.length - 1].value}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Optimal Range</p>
                      <p className="text-green-600">
                        {getOptimalConditions(selectedCrop.type).humidity}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <Droplets size={20} className="text-blue-500 mr-2" />
                    <h4 className="font-medium">Soil Moisture</h4>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Current</p>
                      <p className="text-xl font-bold">
                        {sensorData.soilMoisture[sensorData.soilMoisture.length - 1].value}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Optimal Range</p>
                      <p className="text-green-600">
                        {getOptimalConditions(selectedCrop.type).soilMoisture}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Recommendations */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-blue-600 text-white">
              <h3 className="font-semibold">Crop Management Recommendations</h3>
            </div>
            
            <div className="p-4">
              {selectedCrop.healthIndex < 70 && (
                <div className="mb-4 p-3 bg-amber-50 border-l-4 border-amber-500 rounded-sm">
                  <h4 className="font-medium text-amber-700">Health Alert</h4>
                  <p className="text-sm text-gray-700 mt-1">
                    Crop health index is below optimal levels. Consider increasing nutrient application
                    and monitoring for signs of disease or pest infestation.
                  </p>
                  <button className="mt-2 text-sm text-amber-600 hover:text-amber-800 font-medium">
                    View detailed recommendations
                  </button>
                </div>
              )}
              
              {weatherForecast[0].precipitation > 20 && (
                <div className="mb-4 p-3 bg-blue-50 border-l-4 border-blue-500 rounded-sm">
                  <h4 className="font-medium text-blue-700">Weather Advisory</h4>
                  <p className="text-sm text-gray-700 mt-1">
                    Heavy rainfall expected. Consider postponing any planned fertilizer application
                    and ensure proper drainage systems are functioning.
                  </p>
                  <button className="mt-2 text-sm text-blue-600 hover:text-blue-800 font-medium">
                    View weather forecast
                  </button>
                </div>
              )}
              
              <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded-sm">
                <h4 className="font-medium text-green-700">Growth Stage Action Items</h4>
                <p className="text-sm text-gray-700 mt-1">
                  Current growth stage: {getGrowthStage(selectedCrop.plantingDate, selectedCrop.expectedHarvestDate)}.
                  Follow recommended practices for this stage to ensure optimal yield.
                </p>
                <button className="mt-2 text-sm text-green-600 hover:text-green-800 font-medium">
                  View stage guidelines
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default CropsDashboard;