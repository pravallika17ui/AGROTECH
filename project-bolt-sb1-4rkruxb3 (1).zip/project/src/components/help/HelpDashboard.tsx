import React, { useState } from 'react';
import { 
  Book, 
  HelpCircle, 
  MessageCircle, 
  Video, 
  FileText,
  Search,
  ChevronRight,
  ChevronDown
} from 'lucide-react';

const HelpDashboard: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  
  const helpCategories = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: <Book size={20} />,
      articles: [
        { id: 1, title: 'System Overview', views: 1234 },
        { id: 2, title: 'First Time Setup Guide', views: 987 },
        { id: 3, title: 'Understanding the Dashboard', views: 756 },
        { id: 4, title: 'Basic Navigation', views: 543 }
      ]
    },
    {
      id: 'crop-management',
      title: 'Crop Management',
      icon: <FileText size={20} />,
      articles: [
        { id: 5, title: 'Adding New Crops', views: 890 },
        { id: 6, title: 'Monitoring Crop Health', views: 678 },
        { id: 7, title: 'Setting Growth Stages', views: 567 },
        { id: 8, title: 'Harvest Planning', views: 456 }
      ]
    },
    {
      id: 'irrigation',
      title: 'Irrigation System',
      icon: <Video size={20} />,
      articles: [
        { id: 9, title: 'Irrigation Zones Setup', views: 789 },
        { id: 10, title: 'Scheduling Irrigation', views: 654 },
        { id: 11, title: 'Managing Water Usage', views: 543 },
        { id: 12, title: 'System Maintenance', views: 432 }
      ]
    }
  ];
  
  const popularArticles = [
    {
      id: 1,
      title: 'How to Set Up Automated Irrigation',
      category: 'Irrigation',
      readTime: '5 min'
    },
    {
      id: 2,
      title: 'Understanding Crop Health Indicators',
      category: 'Crops',
      readTime: '7 min'
    },
    {
      id: 3,
      title: 'Configuring Weather Alerts',
      category: 'Weather',
      readTime: '3 min'
    }
  ];
  
  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };
  
  return (
    <div className="py-6 px-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Help Center</h1>
        <p className="text-gray-600">Find answers and learn how to make the most of your system.</p>
      </div>
      
      {/* Search Bar */}
      <div className="mb-8">
        <div className="relative">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search for help articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Help Categories */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-green-600 text-white">
              <h3 className="font-semibold">Help Categories</h3>
            </div>
            
            <div className="divide-y">
              {helpCategories.map(category => (
                <div key={category.id}>
                  <button
                    onClick={() => toggleCategory(category.id)}
                    className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="flex items-center">
                      <span className="text-green-600 mr-3">{category.icon}</span>
                      <span className="font-medium">{category.title}</span>
                    </div>
                    {expandedCategory === category.id ? (
                      <ChevronDown size={20} className="text-gray-400" />
                    ) : (
                      <ChevronRight size={20} className="text-gray-400" />
                    )}
                  </button>
                  
                  {expandedCategory === category.id && (
                    <div className="bg-gray-50 px-4 py-2">
                      {category.articles.map(article => (
                        <button
                          key={article.id}
                          className="w-full p-2 flex items-center justify-between hover:bg-gray-100 rounded-md"
                        >
                          <span className="text-gray-600">{article.title}</span>
                          <span className="text-sm text-gray-400">{article.views} views</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Video Tutorials */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-blue-600 text-white">
              <h3 className="font-semibold">Video Tutorials</h3>
            </div>
            
            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(index => (
                <div
                  key={index}
                  className="bg-gray-50 rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200"
                >
                  <div className="aspect-w-16 aspect-h-9 bg-gray-200">
                    <div className="flex items-center justify-center">
                      <Video size={32} className="text-gray-400" />
                    </div>
                  </div>
                  <div className="p-3">
                    <h4 className="font-medium">Getting Started Tutorial {index}</h4>
                    <p className="text-sm text-gray-500">Duration: 5:30</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Popular Articles */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-amber-600 text-white">
              <h3 className="font-semibold">Popular Articles</h3>
            </div>
            
            <div className="divide-y">
              {popularArticles.map(article => (
                <button
                  key={article.id}
                  className="w-full p-4 text-left hover:bg-gray-50 transition-colors duration-200"
                >
                  <h4 className="font-medium mb-1">{article.title}</h4>
                  <div className="flex items-center text-sm text-gray-500">
                    <span>{article.category}</span>
                    <span className="mx-2">•</span>
                    <span>{article.readTime} read</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
          
          {/* Contact Support */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-purple-600 text-white">
              <h3 className="font-semibold">Need More Help?</h3>
            </div>
            
            <div className="p-4">
              <div className="flex items-center justify-center mb-4">
                <HelpCircle size={48} className="text-purple-600" />
              </div>
              <p className="text-center text-gray-600 mb-4">
                Can't find what you're looking for? Our support team is here to help.
              </p>
              <div className="space-y-2">
                <button className="w-full bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 flex items-center justify-center">
                  <MessageCircle size={20} className="mr-2" />
                  Contact Support
                </button>
                <button className="w-full border border-purple-600 text-purple-600 px-4 py-2 rounded-md hover:bg-purple-50">
                  Submit a Ticket
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpDashboard;