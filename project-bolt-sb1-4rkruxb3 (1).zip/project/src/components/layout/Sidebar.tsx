import React from 'react';
import { LayoutDashboard, Droplets, CloudRain, Plane as Plant, Microscope, Bug, Settings, HelpCircle, ChevronRight } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

interface NavItem {
  name: string;
  icon: React.ReactNode;
  id: string;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, activeTab, setActiveTab }) => {
  const navItems: NavItem[] = [
    { name: 'Dashboard', icon: <LayoutDashboard size={20} />, id: 'dashboard' },
    { name: 'Irrigation', icon: <Droplets size={20} />, id: 'irrigation' },
    { name: 'Weather', icon: <CloudRain size={20} />, id: 'weather' },
    { name: 'Crops', icon: <Plant size={20} />, id: 'crops' },
    { name: 'Soil Health', icon: <Microscope size={20} />, id: 'soil' },
    { name: 'Pest Control', icon: <Bug size={20} />, id: 'pest' },
    { name: 'Settings', icon: <Settings size={20} />, id: 'settings' },
    { name: 'Help', icon: <HelpCircle size={20} />, id: 'help' },
  ];

  return (
    <aside className={`fixed inset-y-0 left-0 bg-green-800 text-white transition-all duration-300 ease-in-out z-20 ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 w-64 flex flex-col`}>
      <div className="p-4 border-b border-green-700">
        <h2 className="text-xl font-bold text-white">AgriSmart</h2>
        <p className="text-green-200 text-sm">Smart Agriculture System</p>
      </div>
      
      <nav className="flex-1 pt-4 overflow-y-auto">
        <ul>
          {navItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center w-full px-4 py-3 transition-colors duration-200 ${
                  activeTab === item.id
                    ? 'bg-green-700 text-white'
                    : 'text-green-100 hover:bg-green-700 hover:text-white'
                }`}
              >
                <span className="mr-4">{item.icon}</span>
                <span>{item.name}</span>
                {activeTab === item.id && (
                  <ChevronRight size={16} className="ml-auto" />
                )}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-green-700">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-green-600 text-white flex items-center justify-center mr-3">
            JF
          </div>
          <div>
            <p className="text-sm font-medium">John Farmer</p>
            <p className="text-xs text-green-300">Green Valley Farm</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;